ADMIN USAGE

1. Deploy site to Netlify.
2. In Netlify site settings -> Environment variables, set:
   ADMIN_ID and ADMIN_PASSWORD
3. Visit /admin-login.html to login.
4. After login, /admin.html is available.
5. Use Gallery Manager to add images, edit title/caption/price, delete images.
   Data is saved in browser localStorage.
